/*
Name: 			App Landing
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	5.7.2
*/

(function( $ ) {

	

}).apply( this, [ jQuery ]);